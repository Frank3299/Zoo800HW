# tobacco-heat-Murphy
Relevant code for High oil tobacco and heat stress paper
